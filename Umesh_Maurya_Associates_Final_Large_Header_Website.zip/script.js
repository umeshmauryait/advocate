const menuToggle = document.getElementById("menuToggle");
const menu = document.getElementById("menu");

menuToggle.addEventListener("click", () => {
  menu.classList.toggle("open");
  menuToggle.textContent = menu.classList.contains("open") ? "✕" : "☰";
});

document.querySelectorAll("#menu a").forEach(link => {
  link.addEventListener("click", () => {
    menu.classList.remove("open");
    menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("name").value.trim() || "there";
  formMessage.textContent = `Thank you, ${name}. Your demo enquiry has been recorded on this page. Connect the form to a backend or email service before publishing.`;
  formMessage.style.color = "#2d6b3b";
  form.reset();
});

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("show");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.14 });

document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

const backTop = document.getElementById('backTop');
window.addEventListener('scroll', () => {
  if (backTop) backTop.classList.toggle('show', window.scrollY > 500);
});
if (backTop) {
  backTop.addEventListener('click', () => window.scrollTo({top: 0, behavior: 'smooth'}));
}


/* ===== Full website content search ===== */
(() => {
  const toggle = document.getElementById('searchToggle');
  const box = document.getElementById('searchBox');
  const input = document.getElementById('siteSearch');
  const close = document.getElementById('searchClose');
  const results = document.getElementById('searchResults');
  const status = document.getElementById('searchStatus');
  if (!toggle || !box || !input || !results) return;

  const searchable = [...document.querySelectorAll('main h1, main h2, main h3, main h4, main p, main li, main a, main label, footer h4, footer a, footer span')]
    .filter(el => !el.closest('.search-box') && el.id !== 'searchStatus');

  const clean = s => s.replace(/\s+/g,' ').trim();
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  let lastQuery = '';

  function removeHighlights(){
    document.querySelectorAll('mark.site-highlight').forEach(m => {
      m.replaceWith(document.createTextNode(m.textContent));
    });
  }

  function highlight(q){
    removeHighlights();
    if(!q) return;
    const re = new RegExp(esc(q), 'gi');
    searchable.forEach(el => {
      if(el.closest('.search-results')) return;
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      const nodes=[];
      while(walker.nextNode()) nodes.push(walker.currentNode);
      nodes.forEach(node => {
        if(!node.nodeValue || !re.test(node.nodeValue)) { re.lastIndex=0; return; }
        re.lastIndex=0;
        const frag=document.createDocumentFragment();
        let last=0, m;
        while((m=re.exec(node.nodeValue))){
          frag.append(document.createTextNode(node.nodeValue.slice(last,m.index)));
          const mark=document.createElement('mark');
          mark.className='site-highlight';
          mark.textContent=m[0];
          frag.append(mark);
          last=m.index+m[0].length;
        }
        frag.append(document.createTextNode(node.nodeValue.slice(last)));
        node.parentNode.replaceChild(frag,node);
      });
    });
  }

  function doSearch(q){
    q=clean(q);
    results.innerHTML='';
    if(!q){
      removeHighlights();
      return;
    }
    const lower=q.toLowerCase();
    const seen=new Set();
    const matches=[];
    searchable.forEach(el=>{
      const text=clean(el.textContent);
      if(text.toLowerCase().includes(lower)){
        const section=el.closest('section, footer') || el;
        const key=section.id || section.className || text.slice(0,80);
        if(!seen.has(key)){
          seen.add(key);
          const idx=text.toLowerCase().indexOf(lower);
          const start=Math.max(0,idx-70);
          const snippet=(start>0?'…':'')+text.slice(start,start+180)+(text.length>start+180?'…':'');
          matches.push({el, title:clean((section.querySelector('h1,h2,h3,h4')||el).textContent)||'Website content', snippet});
        }
      }
    });
    if(!matches.length){
      results.innerHTML='<div class="search-empty">No matching content found.</div>';
      return;
    }
    results.innerHTML=matches.slice(0,12).map((m,i)=>
      `<a href="#${m.el.closest('section,footer')?.id || ''}" class="search-result" data-index="${i}">
        <div class="search-result-title">${m.title}</div>
        <div class="search-result-snippet">${m.snippet}</div>
      </a>`).join('');
    highlight(q);
    const marks=[...document.querySelectorAll('mark.site-highlight')];
    if(marks[0]) marks[0].scrollIntoView({behavior:'smooth',block:'center'});
    if(status){
      status.textContent=`${matches.length} matching section${matches.length===1?'':'s'} found`;
      status.classList.add('show');
      setTimeout(()=>status.classList.remove('show'),2200);
    }
  }

  toggle.addEventListener('click',()=>{
    box.classList.toggle('open');
    if(box.classList.contains('open')) setTimeout(()=>input.focus(),50);
  });
  close.addEventListener('click',()=>{
    box.classList.remove('open');
    input.value='';
    results.innerHTML='';
    removeHighlights();
  });
  input.addEventListener('input',()=>doSearch(input.value));
  input.addEventListener('keydown',e=>{
    if(e.key==='Escape') close.click();
    if(e.key==='Enter') doSearch(input.value);
  });
  document.addEventListener('click',e=>{
    if(!box.contains(e.target) && !toggle.contains(e.target)) box.classList.remove('open');
  });
})();

/* Shrink the top banner/header after the visitor scrolls down. */
(() => {
  const header = document.querySelector('.header');
  const topbar = document.querySelector('.topbar');
  const onScroll = () => {
    const compact = window.scrollY > 70;
    if (header) header.classList.toggle('header-scrolled', compact);
    if (topbar) topbar.classList.toggle('topbar-scrolled', compact);
  };
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();
})();
