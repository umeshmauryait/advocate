UMESH MAURYA & ASSOCIATES — WEBSITE

FILES
- index.html
- style.css
- script.js

HOW TO RUN
1. Extract this ZIP file.
2. Open the folder.
3. Double-click index.html.
4. The website will open in Chrome/Edge/Firefox.

IMPORTANT BEFORE PUBLISHING
Search in index.html and replace:
- +91 XXXXX XXXXX
- 91XXXXXXXXXX
- info@example.com
- Your office address, City, State
- Social media links (#)

The contact form is currently a front-end demo.
To actually receive messages, connect it to your server, Formspree,
Netlify Forms, EmailJS, or another form backend.

DESIGN NOTE
This is an original design inspired by the general professional structure
of the reference law-firm website, not a direct copy.


AI IMAGE UPDATE
The site now includes AI-generated legal photography in assets/: ai-hero-legal.jpg, ai-about-legal.jpg, and ai-consultation-legal.jpg.

FINAL DESIGN UPDATE
- Added a larger, bolder top contact banner.
- Added a premium UM monogram logo/wordmark.
- Added expanded footer columns: Our Expertise, Our Services, Contact Us and Follow Us.
- Added Google Maps search/location links.
- Added floating email/phone buttons and a back-to-top button.
- AI-generated legal images remain included in assets/.
NOTE: Replace placeholder phone, email and office address before publishing. The Google Maps link currently searches for “Umesh Maurya & Associates”; use your exact office address/pin when available.

CONTACT DETAILS UPDATED
Phone: +91 8285628808
Email: umeshrakeshalok@gmail.com
Address: Chamber No. 160, District & Sessions Court, Rohtak, Haryana-124001

SEARCH FEATURE
A search button is placed at the top-right of the navigation. It searches the visible website content, shows matching sections/snippets, scrolls to the first match, and highlights matching words in yellow. Search can be closed with the X button or Escape.

HEADER UPDATE
The top contact banner and main navigation/header are now larger on initial load. The firm name is displayed as a large, bold uppercase wordmark: “UMESH MAURYA & ASSOCIATES”. When the visitor scrolls down, both the top banner and main header compact smoothly to preserve screen space; returning to the top restores the larger version.
